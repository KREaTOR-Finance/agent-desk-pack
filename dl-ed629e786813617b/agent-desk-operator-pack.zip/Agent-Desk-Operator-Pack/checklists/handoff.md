# Handoff checklist (owner → collaborator or future you)
- [ ] Desk name and niche one-liner
- [ ] Where briefs live
- [ ] Current CTA and brand line
- [ ] Routine schedule + timezone
- [ ] Last two gold-example outputs linked
- [ ] Known failure modes
