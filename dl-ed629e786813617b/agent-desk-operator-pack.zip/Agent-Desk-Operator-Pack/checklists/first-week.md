# First-week checklist
- [ ] Agents created and briefs pasted
- [ ] Desk rules + memory contract filled
- [ ] Dry run complete
- [ ] One real DRAFT approved by human
- [ ] Routine scheduled with no-publish guardrails
