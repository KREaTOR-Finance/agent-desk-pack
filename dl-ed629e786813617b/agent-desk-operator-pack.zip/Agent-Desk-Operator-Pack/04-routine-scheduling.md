# 04 — Routine Scheduling

## Goal
The desk runs on a clock so you wake up to a draft, not an empty chat.

## Minimal viable routine
- **When:** one weekday morning (example: Monday 6:00 America/Denver)
- **What wakes:** Scout only
- **Chain:** Scout finishes → Grader → Writer → message you with DRAFT
- **You:** 10–20 minutes to edit and publish (or reject)

## Cadence options
| Cadence | Good for | Risk |
|---------|----------|------|
| Weekly | Newsletters, digests | Low |
| Daily | Social one-liners | Burnout / thin sources |
| Event-driven | “When repo tags a release” | Needs a clean trigger |

Start weekly. Upgrade only after four clean weeks.

## Guardrails in the routine brief
Paste these into the scheduled job description:
1. Do not post, email, purchase, or DM anyone.
2. Cap Scout at N sources (default 8).
3. If sources are thin, Writer outputs “NO BRIEF — not enough sources” instead of padding.
4. Attach the source list every time.
5. Stop after one full Scout→Grader→Writer pass (no retry storms).

## Time zones
Write the zone name in the routine (“America/Denver”), not only “morning.” Agents and hosts drift otherwise.

## When to pause
- You’re traveling and can’t approve drafts
- Brand or CTA is changing
- A source site blocks scrapers — switch Scout to manual paste mode for a week

Next: copy-paste prompts → `05-prompt-library.md`.
