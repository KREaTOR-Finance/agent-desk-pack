# Agent Desk Operator Pack
**Kreation Studios — Agent Tools**  
Version 1.0 · October 2026  
Founding price: $19 (list $27)

## What this is
A practical kit for running a small desk of AI agents that actually finish work.  
Built from real multi-agent setups used to ship game chapters, content pipelines, and research rooms — **rewritten so none of it is financial advice, insurance, or brokerage content**.

You get:
1. Role cards you can paste into new agents
2. A Scout → Grader → Writer pipeline that works for any niche (newsletter, YouTube, blog, product updates)
3. A shared-memory / “super memory” pattern so agents stop contradicting each other
4. A game-studio desk pattern (Story / Build / Polish) you can reuse for creative projects
5. Scheduling and handoff checklists
6. A prompt library and launch checklist

## What this is not
- Not investment, trading, or securities advice  
- Not insurance or compliance software  
- Not a promise you will make money  
- Not a hosted SaaS — you run it in whatever agent host you already pay for (Grok Bot, Claude projects, Cursor agents, etc.)

## How to use it (30 minutes)
1. Read `01-content-pipeline-team.md` and create three agents from the role cards.
2. Drop `templates/scout-brief.md`, `grader-brief.md`, `writer-brief.md` into each agent’s system/instructions field.
3. Put your niche rules in `templates/desk-rules.md` (examples included: product changelog, local events, creator newsletter).
4. Run one dry cycle: Scout gathers → Grader scores → Writer drafts → you approve.
5. When it works twice in a row, add a weekly routine from `04-routine-scheduling.md`.

## Files
```
README.md                          ← you are here
01-content-pipeline-team.md
02-shared-memory-pattern.md
03-game-studio-roles.md
04-routine-scheduling.md
05-prompt-library.md
06-launch-checklist.md
templates/
  scout-brief.md
  grader-brief.md
  writer-brief.md
  desk-rules.md
  memory-contract.md
  story-bot-brief.md
  build-bot-brief.md
  polish-bot-brief.md
checklists/
  first-week.md
  handoff.md
```

## License for buyers
Personal and commercial use of these templates in your own agent setups.  
Do not resell the pack as-is. Attribution to Kreation Studios appreciated, not required.

## Support
Questions about the pack: reply to your purchase receipt email, or open an issue on the product page repo if one is linked in your receipt.
