# Memory contract
## Profile
- Desk:
- Brand line:
- Contact / links we may share:
- Banned topics:
- CTA locked wording:

## Journal (dated decisions)
- YYYY-MM-DD:

## Working (this cycle only — wipe after ship)
- Shortlist:
- Open questions for owner:
