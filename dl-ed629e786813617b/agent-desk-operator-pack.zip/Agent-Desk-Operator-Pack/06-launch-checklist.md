# 06 — Launch Checklist (your desk, first week)

## Day 0
- [ ] Create three agents: Scout, Grader, Writer
- [ ] Paste the three briefs from `templates/`
- [ ] Fill `templates/desk-rules.md` and `templates/memory-contract.md`
- [ ] Run one dry cycle on last week’s topic (no publish)

## Day 1–2
- [ ] Fix whatever broke (missing URLs, weak CTA, tone)
- [ ] Save two example good outputs as “gold” references in memory

## Day 3
- [ ] Add the weekly routine (see `04-routine-scheduling.md`)
- [ ] Confirm the routine cannot post or spend

## Day 4–7
- [ ] Let one real cycle produce a DRAFT
- [ ] You publish manually
- [ ] Note one improvement for next week (not five)

## Done looks like
You received a draft with sources and the correct CTA without babysitting the middle steps.
