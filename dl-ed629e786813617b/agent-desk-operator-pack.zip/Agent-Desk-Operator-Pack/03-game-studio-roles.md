# 03 — Game / Creative Studio Roles

Use this when the “product” is a story, game chapter, comic, or interactive build — not a newsletter.

## Core trio
| Role | Owns | Hands off when |
|------|------|----------------|
| **Story** | Canon, dialogue, chapter beats, “approved text” | Text is marked FINAL by you |
| **Build** | Implementation notes, scene lists, asset requests | Feature works in a playable build |
| **Polish** | Feel, UI, audio, save safety, checklist bugs | Polish backlog items are checked or deferred |

Optional fourth: **Floor / Chief** — prioritizes, blocks scope creep, talks to you once.

## Canon lock
Story keeps a short canon card (characters, open loops, forbidden retcons). Build and Polish may not invent plot. If Build needs a bridge line, Story writes it.

## Vertical slice rule
Before a big chapter, lock a slice: “player can walk from A to B, one fight, one conversation, save/load.” Studio agents work the slice before new maps.

## Playtest loop
1. You play (or someone does).  
2. Polish files bugs as checklist items, not essays.  
3. Build fixes; Story only if dialogue/canon broke.  
4. You re-play the same slice.

## Templates
- `templates/story-bot-brief.md`
- `templates/build-bot-brief.md`
- `templates/polish-bot-brief.md`

## Keep businesses separate
If you also run a commerce or professional desk, **do not** put studio agents in that room. Separate channels / projects / memory contracts.

Next: make the desk show up without you babysitting → `04-routine-scheduling.md`.
