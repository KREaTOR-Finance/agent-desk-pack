# 01 — Content Pipeline Team (Scout → Grader → Writer)

## Why three agents beat one
One mega-prompt tries to research, judge, and write in the same breath. It hallucinates sources, softens bad ideas, and buries the call to action. Split the jobs:

| Role | Job | Must not |
|------|-----|----------|
| **Scout** | Collect candidate items with citations (URLs, titles, dates) | Write the final post or invent facts |
| **Grader** | Score each item against your desk rules; pick a shortlist | Add new facts; rewrite for style |
| **Writer** | Turn the graded shortlist into a draft with CTA and source list | Invent sources; publish without you |

This pattern ships a weekly brief, a changelog digest, a local-events roundup, or a creator newsletter. Swap the niche rules; keep the roles.

## Desk loop (one cycle)
1. You (or a Monday routine) wake **Scout** with: niche, date window, max items (e.g. 8).
2. Scout returns a table: title | one-line why it matters | source URL | date | confidence.
3. **Grader** scores 1–5 on: relevance, freshness, source quality, audience fit. Drops anything under your floor (default 3).
4. **Writer** produces: short spoken/script version OR social post OR email — plus a “Sources” block and **one** CTA you chose in desk rules.
5. You approve. Nothing posts or emails until you say so.

## Hard rules that save you
- Every fact the Writer keeps must appear in Scout’s cited source. If Grader can’t find it, cut it.
- CTA style is fixed in desk rules (example: “Reply to this email” or “Grab the checklist at …”) — Writer may not invent a new ask.
- Brand line is fixed (your name/product only). No borrowing other companies’ names unless the item is about them.
- Drafts are labeled DRAFT until you clear them.

## Niche starter packs (paste into desk-rules.md)
**Creator newsletter:** “Only tools, workflows, and shipping stories. No politics. CTA = reply with what you shipped this week.”  
**Indie game update:** “Only build progress, playtest notes, art. CTA = wishlist / Discord.”  
**Local community board:** “Only dated events within 30 miles. CTA = RSVP link if public.”  
**SaaS changelog digest:** “Only shipped features and breaking changes. CTA = docs link.”

## Failure modes
- Scout dumps headlines with no URLs → reject the run; Scout must retry with links.
- Grader scores everything a 5 → tighten desk rules; add “max 3 items survive.”
- Writer adds vibes without sources → send back with: “Quote or cut.”

Next: wire shared memory so all three agents agree on brand, CTA, and banned topics → `02-shared-memory-pattern.md`.
