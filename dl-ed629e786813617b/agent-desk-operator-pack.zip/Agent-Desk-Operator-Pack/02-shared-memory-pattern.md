# 02 — Shared Memory Pattern (“Super Memory” light)

## Problem
Agent A invents a brand line. Agent B uses last week’s CTA. Agent C “remembers” a rule you never set. You spend the week correcting them.

## Pattern
One **memory contract** every agent on the desk must read before acting. You own the contract. Agents may propose edits; only you (or a designated Memory bot) write them.

### Three layers
1. **Profile (stable):** who you are for this desk, brand line, contact, banned topics.  
2. **Journal (dated):** decisions made this week (“CTA is contact-me, not ask-in-comments”).  
3. **Working notes (ephemeral):** this cycle’s shortlist — discard after publish.

### Memory contract (minimum fields)
See `templates/memory-contract.md`. Fill once, paste into each agent’s “always remember” / shared memory / project knowledge.

### Write rules
- Agents **propose** memory updates in a `## Memory proposals` section at the end of their reply.
- You accept/reject. Never let an agent silently rewrite brand or legal lines.
- When two agents disagree, the contract wins; if the contract is silent, ask you.

### Read rules
- Before a graded shortlist or a draft, Grader and Writer must restate: brand line, CTA, banned topics (one line each). If they can’t, they stop and ask.

### Anti-patterns
- Dumping entire chat logs into “memory” (noise).
- Storing passwords, API keys, or customer PII in agent memory.
- Mixing two businesses in one contract (keep desks separate).

Next: creative desks use the same idea with different roles → `03-game-studio-roles.md`.
